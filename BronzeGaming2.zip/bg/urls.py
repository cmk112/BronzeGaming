from django.conf.urls import url
from django.urls import path, include
from django.contrib import admin
from bronzegaming import views

urlpatterns = [
  path('', views.home, name='home'),
  path('post/new/', views.new_post, name='new_post'),
  path('post/submit/', views.new_post_process, name='new_post_process'),
  path('post/<int:post_id>/', views.view_post, name='view_post'),
  path('user/<str:username>/', views.view_user, name='view_user'),
  path('admin/', admin.site.urls),
  path('accounts/', include('django.contrib.auth.urls')),
  path('signup/', views.signup, name='signup'),
]
