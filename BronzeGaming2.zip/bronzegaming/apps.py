from django.apps import AppConfig


class BronzegamingConfig(AppConfig):
    name = 'bronzegaming'
