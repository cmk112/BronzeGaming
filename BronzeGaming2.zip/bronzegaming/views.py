
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.core.paginator import Paginator


# Create your views here.
from django.shortcuts import render
from django.shortcuts import redirect
from .models import Post
from django.contrib.auth.models import User


# Create your views here.
def home(request):
  posts_list = Post.objects.order_by('-created')
  paginator = Paginator(posts_list, 15)
  page = request.GET.get('page', 1)
  try:
      all_posts = paginator.page(page)
  except PageNotAnInteger:
      all_posts = paginator.page(1)
  except EmptyPage:
      all_posts = paginator.page(paginator.num_pages)
  
  index = all_posts.number - 1  # edited to something easier without index
  # This value is maximum index of your pages, so the last page - 1
  max_index = len(paginator.page_range)
  # You want a range of 7, so lets calculate where to slice the list
  start_index = index - 3 if index >= 3 else 0
  end_index = index + 3 if index <= max_index - 3 else max_index

  final = list(paginator.page_range)[start_index:end_index]

  context = {
    'posts' : all_posts,
    'page_range' : final,
  }
  return render(request, 'main/home.html', context)

@login_required
def new_post(request):
  context = {
  }
  return render(request, 'main/new_post.html', context)

@login_required
def new_post_process(request):
  new_data = Post(title=request.POST.get('title'), body=request.POST.get('body'), username=request.user)
  new_data.save()
  context = {
    'post':new_data
  }
  return redirect('view_post', post_id = new_data.id)

def view_post(request,post_id):
  requested_post = Post.objects.get(id=post_id)
  context = {
    'post':requested_post,
  }
  return render(request, 'main/view_post.html', context)

def view_user(request,username):
  requested_posts = Post.objects.filter(username=User.objects.get(username=username))\
      .order_by('-created')
  context = {
    'posts':requested_posts,
    'username':username
  }
  return render(request, 'main/view_user.html', context)

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})